// next.config.js
module.exports = {
  images: {
    domains: ["sub.id"],
  },
};
